"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    secret_token: process.env.SECRET_TOKEN,
    expires_date: process.env.EXPIRES_DATE,
};
